/*
 Napisati program koji koristi kompleksne brojeve:
  - Definisati strukturu KompleksanBroj koja predstavlja kompleksan broj i sadrži realan i imaginaran deo kompleksnog broja.
 Napisati funkciju koja: 
  - ispisuje kompleksan broj na standardni izlaz, što lepše.
  - učitava kompleksan broj sa standardnog ulaza.
  - računa vrednosti realnog (imaginarnog) dela broja.
  - sabira (oduzima, množi) dva kompleksna broja.
  - računa konjugovano-kompleksni broj svog argumenta.
  - računa moduo kompleksnog broja.
  - računa argument kompleksnog broja.
  
 
 Izvorni kod prvog program iz test_complex.c je sada izdeljen na:
 - complex,c koja predstavlja biblioteku za rad sa kompleksnim brojevima i
 - main.c koja je sadrzi pozive funckija nad kompleksnim brojevima i bitna je samo za ovaj konkretan program
  
 Kako nam je izvorni kod izdeljen, da bi preveli ceo program, treba kompajlirati ova dva .c dokumenta. 
 To postizemo izvrsavanjem sledece komande u terminalu
             gcc -Wall -lm -o izvrsni complex.c main.c
             
             
  Ovakvo pisanje biblioteke ima veliki propust, jer svaka promena u strukturi ili potpisima funkcije zahteva da se iste promene
  urade i u main.c i u compex.c.
 */



#include <stdio.h>
#include <math.h>

/* Definicija tipa KompleksanBroj 
 * je  neophodna da bude ovde navedena jer je neophodno da bude poznato
 *  u main funkciji sta se konretno podrazumeva pod tipom KompleksanBroj */
typedef  struct {
    float real;
    float imag;
} KompleksanBroj;

/* Neophodno je da funkcije koje koristimo budu deklarisane pre koriscenja 
* i iz tog razlog ih moramo ovde navesti. 
* Sve one su definisane izvan ove izvorne datoteke, tj u complex.c */
void ucitaj_kompleksan_broj(KompleksanBroj* z) ;

void ispisi_kompleksan_broj(KompleksanBroj z) ;

float realan_deo(KompleksanBroj z) ;

float imaginaran_deo(KompleksanBroj z);

float moduo(KompleksanBroj  z);

KompleksanBroj konjugovan(KompleksanBroj z) ;

KompleksanBroj saberi(KompleksanBroj z1, KompleksanBroj  z2 ) ;

KompleksanBroj oduzmi(KompleksanBroj z1, KompleksanBroj  z2 ) ;

KompleksanBroj mnozi(KompleksanBroj z1, KompleksanBroj  z2 ) ;

float argument(KompleksanBroj z) ;

/* U main() funckiji testiramo sve funckije koje smo definisali */
int main() {
    /* deklarisemo promenljive tipa KompleksanBroj */
    KompleksanBroj z1, z2;
    
    /* Ucitavamo prvi i ispisujemo ga potom na standardni izlaz  */
    ucitaj_kompleksan_broj(&z1);
    ispisi_kompleksan_broj(z1);
   
    /* Ispisujemo realan, imaginaran deo i moduo kompleksnog broja z1 */
    printf("\nrealan_deo: %.f\nimaginaran_deo: %f\nmoduo %f\n",realan_deo(z1), imaginaran_deo(z1), moduo(z1));
    printf("\n");
    
    /* Ucitavamo i drugi kompleksan broj i ispisujemo ga na standardni izlaz */
    ucitaj_kompleksan_broj(&z2);
    ispisi_kompleksan_broj(z2);
    
    /* Racunamo i ispisujemo konjugovano kompleksan broj od z2 */
    printf("\nNJegov konjugovano kompleksan broj: ");
    ispisi_kompleksan_broj( konjugovan(z2) );
    printf("\n");
   
    /* testiramo sabiranje kompleksnih brojeva */
    printf("\n");
    ispisi_kompleksan_broj(z1);
    printf(" + ");
    ispisi_kompleksan_broj(z2);
    printf("  =  ");
    ispisi_kompleksan_broj(saberi(z1, z2));
    printf("\n");
   
    /* testiramo oduzimanje kompleksnih brojeva */
    printf("\n");
    ispisi_kompleksan_broj(z1);
    printf(" - ");
    ispisi_kompleksan_broj(z2);
    printf("  =  ");
    ispisi_kompleksan_broj(oduzmi(z1, z2));
    printf("\n");
   
    /* testiramo mnozenje kompleksnih brojeva */
    printf("\n");
    ispisi_kompleksan_broj(z1);
    printf(" * ");
    ispisi_kompleksan_broj(z2);
    printf("  =  ");
    ispisi_kompleksan_broj(mnozi(z1, z2));
   
    /* testiramo funkciju koja racuna argument kompleksnih brojeva */
    printf("\n");
    ispisi_kompleksan_broj(z2);
    printf("\nArgument kompleksnog broja %f\n",argument(z2) );
   
    /* program se zavrsava uspesno, tj, bez greske*/
    return 0;
}