/* 
 * Koristimo korektno definisanu biblioteku kompleksnih brojeva. 
 * U zaglavlju complex.h nalazi se definicija komplesnog broja i popis deklaracija podrzanih funkcija
 * a u complex.c se nalaze njihove definicije.
 * 
 * Ovde pisemo i main() funkciju drugaciju od prethodnog zadatka. 
 * 
 * I dalje kompilacija programa se najjednostavnije postize naredbom
 * gcc -Wall -lm -o izvrsni complex.c main.c 
*/


#include <stdio.h>
/* Ukljucujemo zaglavlje neophodno za rad sa kompleksnim brojevima */
#include "complex.h"

/* U main funkciji za uneti kompleksan broj ispisujemo njegov polarni oblik */
int main() {
   KompleksanBroj z;
   
   /* Ucitavamo kompleksan broj */
   ucitaj_kompleksan_broj(&z);
  
   ispisi_kompleksan_broj(z);
   
   printf("\n");
   
   printf("Polarni oblik kompleksnog broj je %.2f *  e^i * %f\n",moduo(z), argument(z));
  
   return 0;
}

