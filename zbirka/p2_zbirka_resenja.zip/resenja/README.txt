
U ovom direktorijumu nalazi se kolekcija rešenja zadataka zbirke

Programiranje 2 - Zbirka zadataka sa rešenjima
Autori: Milena Vujošević Janičić, Jelena Graovac, Nina Radojičić, 
        Ana Spasić, Mirko Spasić, Anđelka Zečević
 
Elektronska verzija zbirke je javno dostupna sa veb-adrese
http://www.programiranje2.matf.bg.ac.rs/

Imena direktorijuma odgovaraju imenima poglavlja zbirke. Izuzetak 
je direktorijum -- biblioteke -- koji sadrži biblioteke funkcija 
koje se često koriste u rešenjima. Redni brojevi zadataka u zbirci 
poklapaju se sa imenima programa u kolekciji.

Ovo delo zaštićeno je licencom Creative Commons CC BY-NC-ND 4.0
Za detalje pogledati LICENSE.txt datoteku.
