/*  zaglavlje ne sadrzi nista bitno vec samo ukljucivanje zaglavlja complex.h
 *
 * Ovo zaglavlje ukljucujemo samo iz razloga da demostiramo problem koji nastaje kada se zaglavlje ne zakljucava 
 */

#include "complex.h"